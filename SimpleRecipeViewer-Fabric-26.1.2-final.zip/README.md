# Simple Recipe Viewer

A lightweight Minecraft 26.1.2 Fabric recipe viewer focused only on browsing items and their crafting recipe displays.

## Target
- Minecraft 26.1.2
- Fabric Loader 0.19.5+
- Fabric API 0.155.3+26.1.2
- Java 25

The project intentionally does not depend on JEI or REI.
