package com.mortada.simplerecipeviewer.client;

import com.mortada.simplerecipeviewer.SEVMadeByMortada;
import com.mortada.simplerecipeviewer.client.ui.RecipeViewerController;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;

public final class SEVMadeByMortadaClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof AbstractContainerScreen<?>) {
                RecipeViewerController.attach(screen);
            }
        });
    }
}
