package com.mortada.simplerecipeviewer.client.recipe;

import net.minecraft.client.Minecraft;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.registries.BuiltInRegistries;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;

/**
 * Reflection-backed compatibility layer for Minecraft 26.1's recipe-display internals.
 * It intentionally avoids depending on a particular internal RecipeManager collection shape.
 */
public final class RecipeIndex {
    private static final List<ItemStack> ITEMS = new ArrayList<>();
    private static final Map<Item, List<Object>> DISPLAYS = new IdentityHashMap<>();
    private static boolean initialized;

    private RecipeIndex() {}

    public static synchronized void refresh() {
        ITEMS.clear();
        DISPLAYS.clear();
        initialized = true;

        // Keep the browser stable and cheap: item registry is immutable after bootstrap.
        for (Item item : BuiltInRegistries.ITEM) {
            ITEMS.add(new ItemStack(item));
        }
        ITEMS.sort(Comparator.comparing(stack -> stack.getHoverName().getString(), String.CASE_INSENSITIVE_ORDER));

        try {
            Object manager = Minecraft.getInstance().getRecipeManager();
            collectRecipes(manager, new IdentityHashMap<>(), 0);
        } catch (Throwable ignored) {
            // A recipe viewer should never crash the client because a mod has an unusual recipe implementation.
        }
    }

    public static List<ItemStack> items() {
        if (!initialized) refresh();
        return Collections.unmodifiableList(ITEMS);
    }

    public static List<Object> displaysFor(ItemStack result) {
        if (!initialized) refresh();
        return DISPLAYS.getOrDefault(result.getItem(), List.of());
    }

    public static List<ItemStack> inputsFor(Object display) {
        List<ItemStack> result = new ArrayList<>();
        if (display == null) return result;
        for (String name : List.of("ingredients", "inputs", "slots", "inputSlots")) {
            try {
                Object value = display.getClass().getMethod(name).invoke(display);
                collectSlotStacks(value, result);
                if (!result.isEmpty()) return result;
            } catch (Throwable ignored) {}
        }
        return result;
    }

    private static void collectSlotStacks(Object value, List<ItemStack> out) {
        if (value == null || out.size() >= 36) return;
        if (value instanceof Iterable<?> it) {
            for (Object o : it) {
                ItemStack stack = resolveSlot(o);
                if (!stack.isEmpty()) out.add(stack);
                if (out.size() >= 36) break;
            }
        } else if (value.getClass().isArray()) {
            int n = Array.getLength(value);
            for (int i = 0; i < n && out.size() < 36; i++) {
                ItemStack stack = resolveSlot(Array.get(value, i));
                if (!stack.isEmpty()) out.add(stack);
            }
        } else {
            ItemStack stack = resolveSlot(value);
            if (!stack.isEmpty()) out.add(stack);
        }
    }

    private static void collectRecipes(Object value, IdentityHashMap<Object, Boolean> seen, int depth) {
        if (value == null || depth > 4 || seen.put(value, Boolean.TRUE) != null) return;

        if (value instanceof Map<?, ?> map) {
            for (Object entry : map.entrySet()) collectRecipes(entry, seen, depth + 1);
            return;
        }
        if (value instanceof Map.Entry<?, ?> entry) {
            collectRecipeCandidate(entry.getValue(), seen, depth + 1);
            return;
        }
        if (value instanceof Iterable<?> iterable) {
            int n = 0;
            for (Object o : iterable) {
                collectRecipeCandidate(o, seen, depth + 1);
                if (++n > 20000) break;
            }
            return;
        }

        // Try common RecipeManager accessors without hard-linking to a mapping name.
        for (String name : List.of("getRecipes", "recipes", "getRecipeMap", "recipeMap")) {
            try {
                Method m = value.getClass().getMethod(name);
                if (m.getParameterCount() == 0) collectRecipes(m.invoke(value), seen, depth + 1);
            } catch (Throwable ignored) {}
        }

        // Last-resort: inspect fields whose names look recipe-related.
        if (depth <= 1) {
            for (Field f : value.getClass().getDeclaredFields()) {
                if (!f.getName().toLowerCase(Locale.ROOT).contains("recipe")) continue;
                try {
                    f.setAccessible(true);
                    collectRecipes(f.get(value), seen, depth + 1);
                } catch (Throwable ignored) {}
            }
        }
    }

    private static void collectRecipeCandidate(Object candidate, IdentityHashMap<Object, Boolean> seen, int depth) {
        if (candidate == null || depth > 5) return;

        // RecipeHolder / recipe objects generally expose display() or displays().
        for (String methodName : List.of("display", "displays", "getDisplays")) {
            try {
                Method m = candidate.getClass().getMethod(methodName);
                if (m.getParameterCount() != 0) continue;
                Object displays = m.invoke(candidate);
                collectDisplayObjects(displays);
                return;
            } catch (Throwable ignored) {}
        }

        // Recipe holders often wrap the recipe in value()/recipe().
        for (String methodName : List.of("value", "recipe", "getRecipe")) {
            try {
                Method m = candidate.getClass().getMethod(methodName);
                if (m.getParameterCount() == 0) collectRecipeCandidate(m.invoke(candidate), seen, depth + 1);
            } catch (Throwable ignored) {}
        }
    }

    private static void collectDisplayObjects(Object displays) {
        if (displays == null) return;
        if (displays instanceof Iterable<?> iterable) {
            for (Object display : iterable) indexDisplay(display);
        } else if (displays.getClass().isArray()) {
            int n = Array.getLength(displays);
            for (int i = 0; i < n; i++) indexDisplay(Array.get(displays, i));
        } else {
            indexDisplay(displays);
        }
    }

    private static void indexDisplay(Object display) {
        if (display == null) return;
        try {
            Object resultSlot = display.getClass().getMethod("result").invoke(display);
            ItemStack result = resolveSlot(resultSlot);
            if (!result.isEmpty()) DISPLAYS.computeIfAbsent(result.getItem(), k -> new ArrayList<>()).add(display);
        } catch (Throwable ignored) {}
    }

    private static ItemStack resolveSlot(Object slot) {
        if (slot == null) return ItemStack.EMPTY;
        if (slot instanceof ItemStack stack) return stack.copy();

        // ItemStackSlotDisplay/ItemSlotDisplay implementations expose one of these accessors.
        for (String name : List.of("stack", "itemStack", "getStack", "getItemStack")) {
            try {
                Object value = slot.getClass().getMethod(name).invoke(slot);
                if (value instanceof ItemStack stack) return stack.copy();
                if (value != null) {
                    ItemStack nested = resolveSlot(value);
                    if (!nested.isEmpty()) return nested;
                }
            } catch (Throwable ignored) {}
        }
        return ItemStack.EMPTY;
    }
}
