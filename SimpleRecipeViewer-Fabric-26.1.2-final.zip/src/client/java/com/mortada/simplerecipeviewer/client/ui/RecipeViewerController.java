package com.mortada.simplerecipeviewer.client.ui;

import com.mortada.simplerecipeviewer.client.recipe.RecipeIndex;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.input.MouseButtonEvent;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Map;

public final class RecipeViewerController {
    private static final Map<Screen, RecipeViewerWidget> PANELS = Collections.synchronizedMap(new IdentityHashMap<>());

    private RecipeViewerController() {}

    public static void attach(Screen screen) {
        if (!(screen instanceof AbstractContainerScreen<?> container)) return;
        if (PANELS.containsKey(screen)) return;

        RecipeIndex.refresh();
        RecipeViewerWidget panel = new RecipeViewerWidget(4, 4, 118, Math.max(96, screen.height - 8));
        container.addRenderableWidget(panel);
        PANELS.put(screen, panel);

        ScreenMouseEvents.afterMouseClick(screen).register((s, event, handled) -> handleClick(s, event));
        ScreenMouseEvents.afterMouseScroll(screen).register((s, mouseX, mouseY, horizontal, vertical, handled) -> {
            RecipeViewerWidget p = PANELS.get(s);
            if (p != null) p.scroll(mouseX, mouseY, vertical);
        });
        ScreenMouseEvents.afterMouseRelease(screen).register((s, event, handled) -> {});
    }

    private static void handleClick(Screen screen, MouseButtonEvent event) {
        RecipeViewerWidget p = PANELS.get(screen);
        if (p != null) p.click(event.x(), event.y());
    }
}
