package com.mortada.simplerecipeviewer.client.ui;

import com.mortada.simplerecipeviewer.client.recipe.RecipeIndex;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Minimal, calm recipe browser panel. */
public final class RecipeViewerWidget extends AbstractWidget {
    private static final int ROW = 22;
    private final List<ItemStack> visible = new ArrayList<>();
    private String query = "";
    private int scroll;
    private ItemStack selected = ItemStack.EMPTY;

    public RecipeViewerWidget(int x, int y, int width, int height) {
        super(x, y, width, height, Component.empty());
        rebuild();
    }

    private void rebuild() {
        visible.clear();
        String q = query.toLowerCase(Locale.ROOT).trim();
        for (ItemStack stack : RecipeIndex.items()) {
            if (q.isEmpty() || stack.getHoverName().getString().toLowerCase(Locale.ROOT).contains(q)) visible.add(stack);
        }
        int max = Math.max(0, visible.size() - Math.max(1, (height - 30) / ROW));
        scroll = Math.max(0, Math.min(scroll, max));
    }

    public void click(double mouseX, double mouseY) {
        if (mouseX < getX() || mouseX >= getX() + width || mouseY < getY() + 28 || mouseY >= getY() + height) return;
        int row = (int) ((mouseY - (getY() + 28)) / ROW) + scroll;
        if (row >= 0 && row < visible.size()) selected = visible.get(row).copy();
    }

    public void scroll(double mouseX, double mouseY, double amount) {
        if (mouseX < getX() || mouseX >= getX() + width || mouseY < getY() || mouseY >= getY() + height) return;
        scroll -= (int) Math.signum(amount) * 3;
        rebuild();
    }

    @Override
    protected void extractWidgetRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        // Background
        g.fill(getX(), getY(), getX() + width, getY() + height, 0xEE111418);
        g.fill(getX(), getY(), getX() + width, getY() + 24, 0xF51B2026);
        g.text(net.minecraft.client.Minecraft.getInstance().font, Component.literal("Recipes"), getX() + 7, getY() + 7, 0xFFFFFFFF, false);

        Font font = net.minecraft.client.Minecraft.getInstance().font;
        int top = getY() + 28;
        int rows = Math.max(1, (height - 30) / ROW);
        int start = Math.min(scroll, Math.max(0, visible.size() - rows));
        for (int i = 0; i < rows && start + i < visible.size(); i++) {
            ItemStack stack = visible.get(start + i);
            int y = top + i * ROW;
            boolean hovered = mouseX >= getX() && mouseX < getX() + width && mouseY >= y && mouseY < y + ROW;
            if (hovered) g.fill(getX() + 2, y, getX() + width - 2, y + ROW, 0xFF2A3038);
            g.item(stack, getX() + 5, y + 2);
            g.text(font, stack.getHoverName(), getX() + 27, y + 6, 0xFFE7EAF0, false);
        }

        if (!selected.isEmpty()) {
            int px = getX() + width + 6;
            int py = getY();
            int pw = 190;
            int ph = 120;
            g.fill(px, py, px + pw, py + ph, 0xF014171B);
            g.text(font, selected.getHoverName(), px + 8, py + 8, 0xFFFFFFFF, false);
            g.item(selected, px + 82, py + 24);
            List<Object> displays = RecipeIndex.displaysFor(selected);
            int count = displays.size();
            g.text(font, Component.literal(count + (count == 1 ? " recipe" : " recipes")), px + 8, py + 62, 0xFFB9C0CA, false);
            if (!displays.isEmpty()) {
                List<ItemStack> inputs = RecipeIndex.inputsFor(displays.get(0));
                int ix = px + 12, iy = py + 82;
                for (int i = 0; i < Math.min(inputs.size(), 9); i++) {
                    int gx = ix + (i % 3) * 22;
                    int gy = iy + (i / 3) * 22;
                    g.item(inputs.get(i), gx, gy);
                }
            } else {
                g.text(font, Component.literal("No display data was exposed by this recipe."), px + 8, py + 80, 0xFF8D96A3, false);
            }
        }
    }


}
