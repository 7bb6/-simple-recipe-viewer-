package com.mortada.simplerecipeviewer;

import net.fabricmc.api.ModInitializer;

public final class SEVMadeByMortada implements ModInitializer {
    public static final String MOD_ID = "simple_recipe_viewer";

    @Override
    public void onInitialize() {
    }
}
